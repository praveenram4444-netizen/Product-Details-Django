import json
import logging
from datetime import datetime

logger = logging.getLogger("api_logger")


class APILogMiddleware:
    def __init__(self, get_response):
        self.get_response = get_response

    def __call__(self, request):
        if request.path.startswith("/"):
            user = request.user if request.user.is_authenticated else "Anonymous"
            method = request.method
            path = request.get_full_path()
            timestamp = datetime.now().isoformat()
            try:
                body = request.body.decode("utf-8")[:1000]
                body = json.loads(body) if body else {}
            except Exception as e:
                body = {}
                logger.info(f"Error decoding request body: {e}")

        resposne = self.get_response(request)
        if request.path.startswith("/api/"):
            logger.info(
                f"API Request: {timestamp} | User: {user} | Method: {method} | Path: {path} | Body: {body}"
            )
        return resposne
