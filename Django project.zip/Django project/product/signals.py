from django.db.models.signals import post_save, post_delete
from django.dispatch import receiver
from .models import Product
from django.core.management import call_command
import os

"""
every time product model is saved or deleted 
taking product.json file backup by running the command 
python manage.py dumpdata product > product.json
"""

# sender - the model or class that sends the signal
# signal -- the actual event that triggers the signal like post_save
# instance -- the acutal instance of the model the action is being performed on
# created -- boolean value that indicates whether a new instance was created or an existing instance was updated
# receiver -- a decorator that listens to signals and responds accordingly


@receiver(post_save, sender=Product)
def backup_product_json(sender, instance, created, **kwargs):
    """
    Signal to backup product data to product.json after saving a Product instance.
    """
    if created:
        print(f"Product {instance.name} created. Backing up to product.json.")
        fixture_path = os.path.join("fixtures", "product.json")
    else:
        print(f"Product {instance.name} updated. Backing up to product.json.")
        fixture_path = os.path.join("fixtures", "product.json")
    # Command to dump data can be executed here if needed, but typically this is done via manage.py command line.
    # checking the folder and the file exists if exists then delete the file
    if os.path.exists(fixture_path):
        os.remove(fixture_path)
    # if the directory does not exist then create the directory
    os.makedirs(os.path.dirname(fixture_path), exist_ok=True)
    # creating the file
    with open(fixture_path, "w") as f:
        call_command("dumpdata", "product", indent=4, stdout=f)
        print(f"Product data backed up to {fixture_path}.")
