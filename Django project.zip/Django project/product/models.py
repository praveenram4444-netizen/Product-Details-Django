from django.db import models
from accounts.models import CustomUser


# creating a comprehensive product model which contains all type of django fields
class Product(models.Model):
    """
    each fields in a model represents a column in the database table
    """

    name = models.CharField(max_length=255)  # charfield used for short text
    description = models.TextField()  # TextField used for long text
    price = models.DecimalField(
        max_digits=10, decimal_places=2
    )  # DecimalField for precise monetary values
    stock = models.IntegerField()  # IntegerField for whole numbers, e.g., stock count
    product_link = models.SlugField(
        max_length=255, unique=True
    )  # SlugField for URL-friendly identifiers
    org_link = models.URLField(
        max_length=255, blank=True, null=True
    )  # URLField for external links, optional
    created_at = models.DateTimeField(
        auto_now_add=True
    )  # used to store creation timestamp
    updated_at = models.DateField(auto_now=True)  # Last update timestamp
    version = models.JSONField(
        blank=True, null=True
    )  # JSONField for storing json data, e.g., version history

    def __str__(self):
        """
        this magical method is used to return a string representation of the model instance
        when it is printed or displayed in the admin interface
        also in the python shell
        """
        return self.name

    # model methods
    def get_final_price(self):
        return self.price - ((self.price * 10) / 100)

    @property
    def offer_detail(self):
        return f"{self.name} has 5% of brand offer and 5% platform offer "

    @classmethod
    def get_total_records(cls):
        return f"total number of prdoucts {len(cls.objects.all().values())}"

    def save(self, *args, **kwargs):
        """
        adding the product name with description while saving
        """
        self.description = f"{self.name} {self.description}"
        super(Product, self).save()

    # adding the constraints to the model
    class Meta:
        """
        Meta class is used to define metadata for the model
        such as ordering, unique constraints, etc.
        """

        ordering = ["-created_at"]  # Order by creation date descending
        constraints = [
            models.UniqueConstraint(
                fields=["name", "product_link"], name="unique_product"
            )
        ]  # Ensure unique product name and link combination
        # since app name and the model name is same changing the model name in database
        db_table = "product"
        # adding unique together constraint
        unique_together = (("name", "price"),)
        # changing the verbose name to display in the admin interface
        verbose_name = "ProductDetails"
        # this is used to change the plural name of the model in the admin interface
        verbose_name_plural = "ProductDetails"
        # be carefule while doing indexing because it will delete the existing data by doing auto vacuum
        # auto vaccum means indexes the datas and if there is invalid datas then thos null column the whole records will be deleted


# creating Orders Model which connects with Product and User
class Order(models.Model):
    user = models.ForeignKey(
        CustomUser, on_delete=models.CASCADE
    )  # Foreign key to the CustomUser model
    product = models.ForeignKey(
        Product, on_delete=models.CASCADE
    )  # Foreign key to the Product model
    quantity = models.PositiveIntegerField()  # Positive integer field for quantity
    order_date = models.DateTimeField(
        auto_now_add=True
    )  # Timestamp for when the order was placed

    def __str__(self):
        return f"{self.user.username} - {self.product.name}"


# Rating model which connects the rated user and the product
class ProductRating(models.Model):
    user = models.ForeignKey(
        CustomUser, on_delete=models.CASCADE
    )  # Foreign key to the CustomUser model
    product = models.ForeignKey(
        Product, on_delete=models.CASCADE
    )  # Foreign key to the Product model
    rating = models.PositiveIntegerField()  # Positive integer field for rating
    review = models.TextField()  # Text field for review comments

    def __str__(self):
        return f"{self.user.username} - {self.product.name} - {self.rating/5}"
