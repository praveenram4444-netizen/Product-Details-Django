from django.forms import Form, ModelForm
from django import forms
from .models import ProductRating, Order


class ProductForm(Form):
    name = forms.CharField(max_length=255)
    price = forms.IntegerField()
    description = forms.CharField(max_length=255)
    stock = forms.IntegerField()


class ProductRatingForm(ModelForm):
    class Meta:
        model = ProductRating
        fields = ["user", "product", "rating", "review"]


class OrderForm(ModelForm):
    class Meta:
        model = Order
        fields = [
            "user",
            "product",
            "quantity",
        ]
