from django.shortcuts import render, redirect
from django.utils.decorators import method_decorator
from django.views.decorators.csrf import csrf_exempt
from django.views.generic import ListView

# impporting djang view to create class based view
from django.views import View
from .models import Product, Order, ProductRating
from django.http import JsonResponse, HttpResponse
import json
from .forms import ProductForm, OrderForm, ProductRatingForm
from accounts.models import CustomUser
from rest_framework.authtoken.models import Token
from .tasks import email_sender


# importing messages from django
from django.contrib import messages


# instead writing different functions for each crud operations we can do it with one class
@method_decorator(csrf_exempt, name="dispatch")
class ProductView(View):
    """
    generating apis for Product model crud operations
    """

    # printing the headers of the model

    def get(self, request):
        headers = request.META.get("HTTP_AUTHORIZATION", None)
        print("headers ", headers)
        if not headers:
            return JsonResponse({"message": "token is missing"})
        token = headers.split(" ")[1]
        user = Token.objects.filter(key=token).first()
        if not user:
            return JsonResponse({"message": "wrong token"})
        products = Product.objects.all()
        product_list = []
        for product in products:
            product_list.append(
                {
                    "name": product.name,
                    "description": product.description,
                    "price": product.price,
                    "stock": product.stock,
                    "product_link": product.product_link,
                    "offer_price": product.get_final_price(),
                    "offer": product.offer_detail,
                    "saved": product.get_total_records(),
                }
            )

        return JsonResponse({"products": product_list})

    def post(self, request):
        """
        the json payload must be look like
        {
            "name":"vivo",
            "description":"mobile with camera with phone call option",
            "price":9000
            "stock":80,
            "product_link":"https://vivo.com",
            "org_link":"https://www.mobile.com"
        }
        """

        data = json.loads(request.body)
        name = data.get("name")
        description = data.get("description")
        price = data.get("price")
        stock = data.get("stock")
        product_link = data.get("product_link")
        org_link = data.get("org_link")

        # creating the product object
        product = Product.objects.create(
            name=name,
            description=description,
            price=price,
            stock=stock,
            product_link=product_link,
            org_link=org_link,
        )
        # sending emails to the org
        email_sender.delay(product_link)
        return JsonResponse(
            {
                "message": "Product created successfully",
                "product_details": {
                    "name": product.name,
                    "desc": product.description,
                    "price": product.price,
                },
            },
            status=201,
        )

    def put(self, request):
        payload = json.loads(request.body)
        # filtering product instance
        id = payload.get("id")
        name = payload.get("name")
        description = payload.get("description")
        price = payload.get("price")
        stock = payload.get("stock")
        product_link = payload.get("product_link")
        org_link = payload.get("org_link")

        # getting the product instance
        product = Product.objects.get(id=id)

        # updating the product instance
        product.name = name
        product.description = description
        product.price = price
        product.stock = stock
        product.product_link = product_link
        product.org_link = org_link
        product.save()

        return JsonResponse(
            {
                "message": "Product updated successfully",
                "product_details": {
                    "name": product.name,
                    "description": product.description,
                    "price": product.price,
                    "stock": product.stock,
                    "product_link": product.product_link,
                    "org_link": product.org_link,
                },
            },
            status=201,
        )

    def delete(self, request):
        payload = json.loads(request.body)
        id = payload.get("id")
        product = Product.objects.get(id=id)
        product.delete()
        return JsonResponse({"message": "Product deleted successfully"}, status=200)


# bulk create view for product
@csrf_exempt
def bulk_create(request):
    """
    bulk create view for product
    """
    if request.method == "POST":
        payload = json.loads(request.body)
        products = payload
        Product.objects.bulk_create(
            [
                Product(
                    name=product.get("name"),
                    description=product.get("description"),
                    price=product.get("price"),
                    stock=product.get("stock"),
                    product_link=product.get("product_link"),
                    org_link=product.get("org_link"),
                )
                for product in products
            ]
        )

        # total count of the records
        number_of_records = Product.objects.all().values()
        return JsonResponse(
            {
                "message": "Products created successfully",
                "total_records_count": len(number_of_records),
            },
            status=201,
        )
    else:
        return JsonResponse({"message": "Invalid request"}, status=400)


# using the generic of django to display content in html
class ProductListView(ListView):
    """
    your class name and the html name must match
    """

    def get_queryset(self):
        return Product.objects.all().order_by("-created_at")

    model = Product
    template_name = "product_list.html"
    context_object_name = "products"


def Productformhtml(request):
    """
    rendering the form in html
    """
    if request.method == "POST":
        form = ProductForm(request.POST)
        if form.is_valid():
            print("form ", form)
            name = form.cleaned_data["name"]
            description = form.cleaned_data["description"]
            price = form.cleaned_data["price"]
            stock = form.cleaned_data["stock"]
            print("name", name, "desc", description, "price", price, "stock", stock)
            Product.objects.create(
                name=name, description=description, price=price, stock=stock
            )

            # redirecting back to product list page
            return redirect("ProductList")
        else:
            return JsonResponse({"message": "Invalid Product Details"}, status=201)
    form = ProductForm()
    return render(request, "product_form.html", {"form": form})


def Orderformhtml(request):
    """
    rendering the form in html
    """
    if request.method == "POST":
        form = OrderForm(request.POST)
        if form.is_valid():
            form.save()
            messages.success(request, "Order created successfully")
            return redirect("ProductList")
        else:
            messages.error(request, "Invalid Order Details")
            return JsonResponse({"message": "Invalid Order Details"}, status=201)
    form = OrderForm()
    products = Product.objects.all()
    users = CustomUser.objects.all()
    return render(
        request, "order_form.html", {"form": form, "products": products, "users": users}
    )


def Ratingformhtml(request):
    """
    rendering the form in html
    """
    if request.method == "POST":
        form = ProductRatingForm(request.POST)
        if form.is_valid():
            form.save()
            messages.success(request, "Rating created successfully")
            return redirect("ProductList")
        else:
            messages.error(request, "rating is invalid")
            return JsonResponse({"message": "Invalid Rating Details"}, status=201)
    form = ProductRatingForm()
    products = Product.objects.all()
    users = CustomUser.objects.all()

    return render(
        request,
        "rating_form.html",
        {"form": form, "products": products, "users": users},
    )
