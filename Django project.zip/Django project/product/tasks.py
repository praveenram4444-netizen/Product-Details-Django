import time
from celery import shared_task


@shared_task
def email_sender(email):
    time.sleep(10)
    print("email sending completing")
