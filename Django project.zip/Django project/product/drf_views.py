from rest_framework.response import Response
from rest_framework.decorators import api_view
from .serializers import OrderSerializer, ProductRatingSerializer, ProductSerializer
from .models import Order, ProductRating, Product
from rest_framework.views import APIView
from rest_framework.viewsets import ModelViewSet
from rest_framework.decorators import action


@api_view(["GET", "POST"])
def orderview(request):

    if request.method == "GET":
        order = Order.objects.all()
        serializer = OrderSerializer(order, many=True)
        return Response({"orders": serializer.data})
    elif request.method == "POST":
        serializer = OrderSerializer(data=request.data)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data)
        return Response(serializer.errors)


class OrderUpdate(APIView):
    def get(self, request, pk):
        order = Order.objects.get(id=pk)
        serializer = OrderSerializer(order)
        return Response(serializer.data)

    def put(self, request, pk):
        order = Order.objects.get(id=pk)
        serializer = OrderSerializer(order, data=request.data)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data)
        return Response(serializer.errors)

    def delete(self, request, pk):
        order = Order.objects.get(id=pk)
        order.delete()
        return Response({"message": "Order deleted successfully"})


class ProductViewset(ModelViewSet):
    serializer_class = ProductSerializer
    queryset = Product.objects.all()

    # rating path adding
    @action(detail=True, methods=["get"], url_path="ratings")
    def get_ratings(self, request, pk=None):
        product = self.get_object()
        ratings = ProductRating.objects.filter(product=product)

        serializer = ProductRatingSerializer(ratings, many=True)
        return Response({"ratings": serializer.data})


class OrderViewset(ModelViewSet):
    serializer_class = OrderSerializer
    queryset = Order.objects.all()


class RatingViewset(ModelViewSet):
    serializer_class = ProductRatingSerializer
    queryset = ProductRating.objects.all()


# to dump any data using manage.py dumpdata product > product.json
