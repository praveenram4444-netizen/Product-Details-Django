from django.contrib import admin
from .models import Product, Order, ProductRating


class ProductAdmin(admin.ModelAdmin):
    list_display = ("created_at", "name", "price", "stock", "offer_price", "updated_at")

    # enabling editable in teh list display views itself
    list_editable = ("name", "price", "stock")

    search_fields = ("name", "price")
    list_filter = ("name", "stock")
    ordering = ("name", "price")

    fieldsets = (
        ("primary info", {"fields": ("name", "price", "stock", "description")}),
        (
            "contact details",
            {
                "fields": (
                    "product_link",
                    "org_link",
                )
            },
        ),
        ("versioning", {"fields": ("version",)}),
    )

    # when we create a new record for that record this field will prepopulate
    # prepopulated_fields = {"slug": ("name", "description")}
    # disable the edit option for the import fields, making the fields as readonly
    readonly_fields = ("version", "org_link", "product_link")

    # creating a function and display that result in to the admin panel
    def offer_price(self, obj):
        return obj.price - ((obj.price * 10) / 100)


class OrderAdmin(admin.ModelAdmin):
    def product_name(self, obj):
        return obj.product.name

    def product_price(self, obj):
        return obj.product.price

    list_display = ("user", "product_name", "product_price", "quantity")


admin.site.register(Product, ProductAdmin)
admin.site.register(Order, OrderAdmin)
admin.site.register(ProductRating)
