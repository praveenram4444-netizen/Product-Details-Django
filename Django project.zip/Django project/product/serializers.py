from rest_framework.serializers import ModelSerializer, SerializerMethodField
from .models import Order, ProductRating, Product
from accounts.models import CustomUser


class OrderSerializer(ModelSerializer):
    """
    a serializer - serialize the data from db for jsonresponse
    when we receive data it will validate and load back to table
    """

    user_details = SerializerMethodField()
    prod_details = SerializerMethodField()

    def get_user_details(self, obj):
        instance = CustomUser.objects.get(id=obj.user.id)
        return {"name": instance.first_name, "email": instance.email}

    def get_prod_details(self, obj):
        instance = Product.objects.get(id=obj.product.id)
        return {
            "name": instance.name,
            "price": instance.price,
            "desc": instance.description,
        }

    class Meta:
        model = Order
        fields = "__all__"


class ProductRatingSerializer(ModelSerializer):
    class Meta:
        model = ProductRating
        fields = "__all__"


class ProductSerializer(ModelSerializer):
    class Meta:
        model = Product
        fields = "__all__"
