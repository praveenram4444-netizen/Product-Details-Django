from django.apps import AppConfig


class ProductConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "product"

    def ready(self):
        # Import signals to ensure they are registered
        import product.signals  # noqa: F401

        # Import views to ensure they are registered
        import product.views  # noqa: F401

        # Import DRF views to ensure they are registered
        import product.drf_views  # noqa: F401
