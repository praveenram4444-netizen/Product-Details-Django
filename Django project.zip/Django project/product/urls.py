from django.urls import path, include
from .views import (
    ProductView,
    bulk_create,
    ProductListView,
    Productformhtml,
    Orderformhtml,
    Ratingformhtml,
)
from .drf_views import (
    orderview,
    OrderUpdate,
    ProductViewset,
    OrderViewset,
    RatingViewset,
)
from rest_framework.routers import DefaultRouter

router = DefaultRouter()

router.register("product", ProductViewset, basename="product")
router.register("order", OrderViewset, basename="order")
router.register("rating", RatingViewset, basename="rating")

urlpatterns = [
    path("crud/", ProductView.as_view(), name="product"),
    path("bulk/", bulk_create),
    path("productlist/", ProductListView.as_view(), name="ProductList"),
    path("order/", orderview),
    path("order/<int:pk>/", OrderUpdate.as_view(), name="orderupdate"),
    path("prdouctform/", Productformhtml, name="productform"),
    path("orderform/", Orderformhtml, name="orderform"),
    path("ratingform/", Ratingformhtml, name="ratingform"),
    path("", include(router.urls)),
]
