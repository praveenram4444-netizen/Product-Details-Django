from django.contrib import admin
from .models import Author, Book, AuthorProfile, Genre

# Register your models here.
admin.site.register(Author)
admin.site.register(Book)
admin.site.register(AuthorProfile)
admin.site.register(Genre)
