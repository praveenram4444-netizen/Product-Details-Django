from django.db import models


# Create your models here.
class Author(models.Model):
    """
    the query get the book details from author is
    author = Author.objects.get(name="authoname")
    author.books.all() # this will return all the books writter by the author

    example:
        >>> from library.models import Author, Book
        >>> a1 = Author.objects.get(name="j.k.rowling")
        >>> a1.books.all().values()
        <QuerySet [{'id': 1, 'title': 'harrypotter and sorcerar stone', 'author_id': 1, 'published_date': datetime.date(2025, 9, 20), 'isbn_number': '4354'}, {'id': 2, 'title': 'harry potter and goblet of fire', 'author_id': 1, 'published_date': datetime.date(2025, 9, 20), 'isbn_number': '4234'}]>
        >>>
    """

    name = models.CharField(max_length=255)
    email = models.EmailField(unique=True)

    def __str__(self):
        return str(self.name)


class Book(models.Model):
    """
    accessing authon details via book instance
    >>> b1 = Book.objects.get(id=1)
    >>> b1.title
    'harrypotter and sorcerar stone'
    >>> b1.author.name
    'j.k.rowling'
    >>> b1.author.email
    'rowling@gmail.com'
    """

    title = models.CharField(max_length=255)
    author = models.ForeignKey(
        Author, on_delete=models.CASCADE, related_name="books"
    )  # using related name we can access book details from authon
    published_date = models.DateField()
    isbn_number = models.CharField(max_length=13, unique=True)

    def __str__(self):
        return str(self.title)


class AuthorProfile(models.Model):
    """
    one record in one model is linked to exactly one record in another model
    example:
    >>> from library.models import Author, AuthorProfile
    >>> author = Author.objects.get(name = "j.k.rowling")
    >>> author.profile.biography
    'name- j.k.rowling, country-england, gender-female'
    >>> p1 = AuthorProfile.objects.get(id=1)
    >>> p1.author.name
    'j.k.rowling'
    """

    author = models.OneToOneField(
        Author, on_delete=models.CASCADE, related_name="profile"
    )
    biography = models.TextField()
    website = models.URLField(blank=True, null=True)

    def __str__(self):
        return f"Profile of {self.author.name}"


class Genre(models.Model):
    """
    many to many relationship:
        one record in one model is connected with multiple records in another model likewise
        another model record is also connected with multiple records in first model

    """

    name = models.CharField(max_length=100, unique=True)
    description = models.TextField(blank=True, null=True)
    books = models.ManyToManyField(Book, related_name="genres")

    def __str__(self):
        return self.name
