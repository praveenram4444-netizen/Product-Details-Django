from django.contrib import admin
from .models import CustomUser

# user admin used for managing the custom user model in the admin interface
from django.contrib.auth.admin import UserAdmin


class CustomUserAdmin(UserAdmin):
    model = CustomUser
    list_display = ("email", "first_name", "last_name", "is_staff", "is_active")
    list_filter = ("is_staff", "is_active")
    fieldsets = (
        (None, {"fields": ("email", "password")}),
        (
            "Personal info",
            {
                "fields": (
                    "username",
                    "first_name",
                    "last_name",
                    "phone_number",
                    "address",
                )
            },
        ),
        ("Permissions", {"fields": ("is_staff", "is_active")}),
    )
    # This is used for creating new users in the admin interface with selected fields
    add_fieldsets = (
        (
            None,
            {
                "classes": ("wide",),
                "fields": ("email", "password1", "password2", "is_staff", "is_active"),
            },
        ),
    )
    search_fields = ("email",)
    ordering = ("email",)


# Register the CustomUser model with the admin site
admin.site.register(CustomUser, CustomUserAdmin)
