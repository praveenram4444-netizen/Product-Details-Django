"""

fields -- charfields -- max_length -- stoes short strings(defining length of the string)
default -- if no values is provided for the field this value will be used
null = True -- database will take null values for this field
blank = True -- while displaying the form this field can be left as blank
choices -- fixed options for the filed
db_index = True -- creates an index in the  database for faster lookups
unique = True -- ensures all the values for field must be unique
validators -- to create a custom validation for the field values
editable = False -- this specified field will not displayed in the admin panel or any model form
help_text -- shows help text in the form and admin panel
verbose_name -- a human readable name for the field
auto_now-- automatically set the field to now every time of the object getting saved
auto_now_add -- automatically set the field to now when the object is first created
Jsonfield -- to store the dictionary type of json data
upload_to -- to indicate the directory within media root where the file will be stored
related_name -- to access the related objects from the other related model
on_delete -- to specify the action to be taken when the connected object from other model is getting deleted , CASCADE, PROTECT,SET_NULL,SET_DEFAULT, DO_NOTHING


"""

from django.db import models

# customize the user model
from django.contrib.auth.models import AbstractUser, BaseUserManager, PermissionsMixin
from rest_framework.authtoken.models import Token


# handling user creation and management
class CustomUserManager(BaseUserManager):
    def create_user(self, email, password=None, **extra_fields):
        if not email:
            raise ValueError("The Email field must be set")
        email = self.normalize_email(email)
        # self.model is the CustomUser model
        user = self.model(email=email, **extra_fields)
        # here we encode the password and add the user to the database
        user.set_password(password)
        user.save(using=self._db)
        return user

    def create_superuser(self, email, password=None, **extra_fields):
        extra_fields.setdefault("is_staff", True)
        extra_fields.setdefault("is_superuser", True)

        return self.create_user(email, password, **extra_fields)


class CustomUser(AbstractUser, PermissionsMixin):
    email = models.EmailField(unique=True)  # Use email as the unique identifier
    first_name = models.CharField(max_length=30, blank=True)  # Optional first name
    last_name = models.CharField(max_length=30, blank=True)  # Optional last name
    is_active = models.BooleanField(default=True)  # Active status
    is_staff = models.BooleanField(default=False)  # Staff status for admin access
    phone_number = models.CharField(
        max_length=15, blank=True, null=True
    )  # Optional phone number
    address = models.CharField(
        max_length=255, blank=True, null=True
    )  # Optional address
    # phone = models.CharField(max_length=50, choices=[("mobile","Mobile"), ("landline","Landline")], default="mobile")

    USERNAME_FIELD = "email"  # Set email as the username field
    REQUIRED_FIELDS = []  # No required fields other than email

    objects = CustomUserManager()  # Use the custom user manager

    def __str__(self):
        return self.email  # Return email as string representation of the user

    def save(self, *args, **kwargs):
        super().save(*args, **kwargs)
        # Create a token for the user when they are created
        if not hasattr(self, "auth_token"):
            Token.objects.create(user=self)
