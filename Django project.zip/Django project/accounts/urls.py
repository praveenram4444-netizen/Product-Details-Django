from .views import login_view, signup_view, update_profile, delete_profile
from django.urls import path

urlpatterns = [
    path("login/", login_view, name="login"),
    path("signup/", signup_view, name="signup"),
    path("update-profile/", update_profile, name="update_profile"),
    path("delete-profile/", delete_profile, name="delete_profile"),
]
