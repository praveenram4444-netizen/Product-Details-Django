from django.shortcuts import render
from django.views.decorators.csrf import csrf_exempt
from django.http import JsonResponse

# importing login, logout, and authenticate from django.contrib.auth
from django.contrib.auth import login, logout, authenticate
from django.contrib.auth.decorators import login_required
import json
from .models import CustomUser  # Importing the custom user model
from rest_framework.authtoken.models import Token


# crating a loging view using basic django authentication
@csrf_exempt  # csrf_exempt is used to exempt this view from CSRF verification
def login_view(request):
    """
    this view handles apis not html pages
    it allows users to log in using their email and password
    """
    if request.method == "POST":
        # Extracting email and password from the request body converting it into json
        data = json.loads(request.body)
        email = data.get("email")
        password = data.get("password")
        print(email, password)
        user = authenticate(request, username=email, password=password)

        if user is not None:
            login(request, user)
            token = Token.objects.get(user=user)
            return JsonResponse(
                {
                    "message": "Login successful",
                    "userdetails": {
                        "email": user.email,
                        "first_name": user.first_name,
                        "is_staff": user.is_staff,
                        "is_active": user.is_active,
                        "phone_number": user.phone_number,
                        "address": user.address,
                        "token": token.key,
                    },
                },
                status=200,
            )
        else:
            return JsonResponse({"error": "Invalid credentials"}, status=400)

    return JsonResponse({"error": " GET Method not allowed"}, status=405)


# singup api
@csrf_exempt
def signup_view(request):
    """
    this view handles apis not html pages
    it allows users to sign up using their email and password
    the payload structure is:
    {
        "email": "admin@sample.com",
        "password": "admin123",
        "first_name": "Admin",
        "last_name": "User",
        "phone_number": "1234567890",
        "address": "123 Admin Street, Admin City, Admin Country"
    }
    """
    if request.method == "POST":

        data = json.loads(request.body)
        email = data.get("email")
        password = data.get("password")
        first_name = data.get("first_name", "")
        last_name = data.get("last_name", "")
        phone_number = data.get("phone_number", "")
        address = data.get("address", "")
        # verifying the user already exists or not
        if CustomUser.objects.filter(email=email).exists():
            return JsonResponse({"error": "User already exists"}, status=400)

        # Create a new user
        # to encode the password we must add that in our payload while creating the user
        user = CustomUser.objects.create_user(
            email=email,
            first_name=first_name,
            last_name=last_name,
            phone_number=phone_number,
            address=address,
            username=first_name + last_name,  # Use email as username
            password=password,  # Password will be set later
        )

        return JsonResponse(
            {
                "message": "User created successfully",
                "userdetails": {
                    "email": user.email,
                    "first_name": user.first_name,
                    "is_staff": user.is_staff,
                    "is_active": user.is_active,
                    "phone_number": user.phone_number,
                    "address": user.address,
                },
            },
            status=201,
        )

    return JsonResponse({"error": " GET Method not allowed"}, status=405)


# update user profile
@login_required
@csrf_exempt
def update_profile(request):
    """
    this view handles apis not html pages
    it allows users to update their profile information
    the payload structure is:
    {
        "first_name": "NewFirstName",
        "last_name": "NewLastName",
        "phone_number": "9876543210",
        "address": "456 New Street, New City, New Country"

    }
    """
    if request.method == "POST":
        user = request.user
        data = json.loads(request.body)
        first_name = data.get("first_name", user.first_name)
        last_name = data.get("last_name", user.last_name)
        phone_number = data.get("phone_number", user.phone_number)
        address = data.get("address", user.address)

        # retrieving the user from the database
        instance = CustomUser.objects.get(email=user.email)
        instance.first_name = first_name
        instance.last_name = last_name
        instance.phone_number = phone_number
        instance.address = address
        instance.save()
        return JsonResponse(
            {
                "message": "Profile updated successfully",
                "userdetails": {
                    "email": user.email,
                    "first_name": instance.first_name,
                    "last_name": instance.last_name,
                    "is_staff": user.is_staff,
                    "is_active": user.is_active,
                    "phone_number": instance.phone_number,
                    "address": instance.address,
                },
            },
            status=200,
        )
    return JsonResponse({"error": " GET Method not allowed"}, status=405)


# deleting the user profile
@login_required
@csrf_exempt
def delete_profile(request):
    """
    this view never deletes the user profile only it deactivates the user profile
    we call that soft delete we can do that by deactivating the user profile
    is_active = False
    """
    if request.method == "POST":
        user = request.user
        print("user detial ", user.email)
        # retrieving the user from the database
        instance = CustomUser.objects.get(email=user.email)
        # inalternative if we want to delete the user try
        # instance.delete()
        instance.is_active = False
        instance.save()
    return JsonResponse(
        {
            "message": "Profile disabled successfully",
            "userdetails": {
                "email": user.email,
                "first_name": instance.first_name,
                "last_name": instance.last_name,
                "is_staff": user.is_staff,
                "is_active": instance.is_active,
                "phone_number": instance.phone_number,
                "address": instance.address,
            },
        },
        status=200,
    )
